"""
NovelViews Assets — Blender Add-on

Exposes the three blender_scripts as operators accessible from a sidebar panel:
  - Setup Hunyuan3D Cameras (blender_camera_setup)
  - Create Camera Tour      (blender_camera_tour)
  - Normalize Mesh          (blender_normalize_mesh)

Install:
  1. Zip the blender_addon/ folder (the zip must contain __init__.py at its root).
  2. In Blender: Edit > Preferences > Add-ons > Install … > select the zip.
  3. Enable "3D View: NovelViews Assets".
  4. Open the N-panel in the 3D Viewport and find the "NovelViews" tab.
"""

bl_info = {
    "name": "NovelViews Assets",
    "author": "leob03",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > NovelViews",
    "description": "Hunyuan3D MultiView camera setup, camera tour, and mesh normalization",
    "category": "3D View",
}

import bpy
import math
from mathutils import Vector, Matrix, Quaternion
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty, PointerProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


# ---------------------------------------------------------------------------
# Shared camera math (mirroring the logic in the original scripts exactly)
# ---------------------------------------------------------------------------

def _get_camera_position_hunyuan(elev, azim, distance):
    elev_rad = math.radians(-elev)
    azim_rad = math.radians(azim + 90)
    x = distance * math.cos(elev_rad) * math.cos(azim_rad)
    y = distance * math.cos(elev_rad) * math.sin(azim_rad)
    z = distance * math.sin(elev_rad)
    return Vector((x, y, z))


def _hunyuan_to_blender(pos):
    """Inverse of Hunyuan3D's mesh transform (-X, Z, -Y) applied to camera pos."""
    return Vector((-pos.x, -pos.z, pos.y))


def _blender_pos_for_view(view_name, distance):
    azim, elev = _VIEW_TO_AZIM_ELEV[view_name]
    return _hunyuan_to_blender(_get_camera_position_hunyuan(elev, azim, distance))


# View definitions shared by both operators
_CAMERA_AZIMS = [0, 90, 180, 270, 0, 180, 270, 90]
_CAMERA_ELEVS = [0, 0, 0, 0, 90, -90, -45, -45]
_VIEW_NAMES   = ["top", "right", "bottom", "left", "back", "front", "front_left", "front_right"]

_VIEW_UP_AXIS = {"top": "UP_Z", "bottom": "UP_X"}
_DEFAULT_UP   = "UP_Y"
_VIEW_Z_ROT   = {"bottom": math.pi / 2}   # extra Z rotation after track_quat

_VIEW_TO_AZIM_ELEV = {
    "top":         (0,    0),
    "right":       (90,   0),
    "bottom":      (180,  0),
    "left":        (270,  0),
    "back":        (0,   90),
    "front":       (180, -90),
    "front_left":  (270, -45),
    "front_right": (90,  -45),
}

_TOUR_TRAJECTORY = [
    "front", "front_left", "left", "back",
    "right", "front_right", "front", "top", "back", "bottom",
]


# ---------------------------------------------------------------------------
# Scene properties (all user-facing parameters)
# ---------------------------------------------------------------------------

class NovelViewsProperties(PropertyGroup):
    # ---- Camera Setup ----
    camera_distance: FloatProperty(
        name="Camera Distance",
        description="Distance from camera to origin",
        default=1.45, min=0.01, max=20.0, step=1,
    )
    ortho_scale: FloatProperty(
        name="Ortho Scale",
        description="Orthographic camera scale (>=1.15 to fit a normalized mesh)",
        default=1.2, min=0.01, max=20.0, step=1,
    )
    render_size: IntProperty(
        name="Render Size (px)",
        description="Square render resolution",
        default=1024, min=64, max=8192,
    )
    use_constraints: BoolProperty(
        name="Use Track-To Constraint",
        description="Attach a Track-To constraint instead of baking rotation (easier to adjust later)",
        default=True,
    )

    # ---- Camera Tour ----
    travel_seconds: FloatProperty(
        name="Travel Duration (s)",
        description="Total movement time across all segments (pauses are added on top)",
        default=5.0, min=0.1, max=300.0, step=10,
    )
    pause_seconds: FloatProperty(
        name="Pause per Waypoint (s)",
        description="Hold time inserted at each waypoint",
        default=0.2, min=0.0, max=30.0, step=1,
    )

    # ---- Normalize Mesh ----
    mesh_scale_factor: FloatProperty(
        name="Bounding Sphere Diameter",
        description="Target bounding-sphere diameter (Hunyuan3D default: 1.15)",
        default=1.15, min=0.001, max=1000.0, step=1,
    )


# ---------------------------------------------------------------------------
# Operator: Setup Hunyuan3D Cameras
# ---------------------------------------------------------------------------

class NOVELVIEWS_OT_setup_cameras(Operator):
    bl_idname  = "novelviews.setup_cameras"
    bl_label   = "Setup Cameras"
    bl_description = (
        "Create 8 orthographic cameras matching the Hunyuan3D MultiView viewpoints "
        "and configure render settings"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.novelviews_props
        cameras = self._create_cameras(context, props)
        self._setup_render(context, props)
        if cameras:
            context.scene.camera = cameras[0]
        self.report({"INFO"}, f"Created {len(cameras)} Hunyuan3D cameras in 'Hunyuan3D_Cameras' collection")
        return {"FINISHED"}

    # ------------------------------------------------------------------
    def _create_cameras(self, context, props):
        col_name = "Hunyuan3D_Cameras"
        if col_name in bpy.data.collections:
            col = bpy.data.collections[col_name]
            for obj in list(col.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
        else:
            col = bpy.data.collections.new(col_name)
            context.scene.collection.children.link(col)

        # Target empty for Track-To constraints
        target = None
        if props.use_constraints:
            t_name = "Hy3D_Camera_Target"
            if t_name in bpy.data.objects:
                target = bpy.data.objects[t_name]
            else:
                target = bpy.data.objects.new(t_name, None)
                col.objects.link(target)
            target.location = (0, 0, 0)
            target.empty_display_type  = "SPHERE"
            target.empty_display_size  = 0.1

        cameras = []
        for azim, elev, name in zip(_CAMERA_AZIMS, _CAMERA_ELEVS, _VIEW_NAMES):
            pos = _hunyuan_to_blender(_get_camera_position_hunyuan(elev, azim, props.camera_distance))

            cam_data = bpy.data.cameras.new(name=f"Hy3D_Camera_{name}")
            cam_data.type        = "ORTHO"
            cam_data.ortho_scale = props.ortho_scale
            cam_data.clip_start  = 0.1
            cam_data.clip_end    = 100.0

            cam_obj = bpy.data.objects.new(f"Hy3D_Camera_{name}", cam_data)
            col.objects.link(cam_obj)
            cam_obj.location = pos

            z_offset = _VIEW_Z_ROT.get(name, 0)

            if props.use_constraints and z_offset == 0:
                c = cam_obj.constraints.new(type="TRACK_TO")
                c.target     = target
                c.track_axis = "TRACK_NEGATIVE_Z"
                c.up_axis    = _VIEW_UP_AXIS.get(name, _DEFAULT_UP)
            else:
                direction = (Vector((0, 0, 0)) - pos).normalized()
                up_ref    = _VIEW_UP_AXIS.get(name, _DEFAULT_UP).replace("UP_", "")
                rot       = direction.to_track_quat("-Z", up_ref).to_euler()
                if z_offset:
                    rot.z += z_offset
                cam_obj.rotation_euler = rot

            cameras.append(cam_obj)

        return cameras

    def _setup_render(self, context, props):
        s = context.scene
        s.render.resolution_x        = props.render_size
        s.render.resolution_y        = props.render_size
        s.render.resolution_percentage = 100
        s.render.film_transparent    = True


# ---------------------------------------------------------------------------
# Operator: Camera Tour
# ---------------------------------------------------------------------------

class NOVELVIEWS_OT_camera_tour(Operator):
    bl_idname  = "novelviews.camera_tour"
    bl_label   = "Create Camera Tour"
    bl_description = (
        "Bake a single animated orthographic camera travelling through all "
        "Hunyuan3D viewpoints with configurable travel speed and waypoint pauses"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.novelviews_props
        col   = self._ensure_collection("Hunyuan3D_PathCamera")
        cam   = self._make_camera(context, col, props)
        # optional visual target
        tgt   = bpy.data.objects.new("Hy3D_PathTarget", None)
        tgt.empty_display_type = "SPHERE"
        tgt.empty_display_size = 0.08
        tgt.location = (0, 0, 0)
        col.objects.link(tgt)

        self._bake(context, cam, _TOUR_TRAJECTORY, props)
        self.report({"INFO"}, "Camera tour baked — scrub the timeline to preview")
        return {"FINISHED"}

    # ------------------------------------------------------------------
    def _ensure_collection(self, name):
        if name in bpy.data.collections:
            col = bpy.data.collections[name]
            for obj in list(col.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            return col
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
        return col

    def _make_camera(self, context, col, props):
        cam_data = bpy.data.cameras.new("Hy3D_PathCam")
        cam_data.type        = "ORTHO"
        cam_data.ortho_scale = props.ortho_scale
        cam_data.clip_start  = 0.1
        cam_data.clip_end    = 100.0
        cam_obj = bpy.data.objects.new("Hy3D_PathCam", cam_data)
        col.objects.link(cam_obj)
        context.scene.camera = cam_obj
        return cam_obj

    # --- math helpers (same as blender_camera_tour.py) ---

    @staticmethod
    def _clamp(x, a, b):
        return max(a, min(b, x))

    def _slerp(self, u, v, t):
        dot   = self._clamp(u.dot(v), -1.0, 1.0)
        omega = math.acos(dot)
        if omega < 1e-9:
            return u.copy()
        so = math.sin(omega)
        return ((math.sin((1.0 - t) * omega) / so) * u +
                (math.sin(t * omega) / so) * v).normalized()

    @staticmethod
    def _rotation_from_forward_up(forward, up):
        f = forward.normalized()
        r = f.cross(up.normalized())
        if r.length < 1e-8:
            alt = Vector((1, 0, 0)) if abs(f.dot(Vector((1, 0, 0)))) < 0.9 else Vector((0, 1, 0))
            r = f.cross(alt)
        r.normalize()
        u        = r.cross(f).normalized()
        backward = (-f).normalized()
        return Matrix((r, u, backward)).transposed().to_quaternion()

    @staticmethod
    def _parallel_transport_up(prev_fwd, fwd, prev_up):
        f = fwd.normalized()
        u = prev_up - f * prev_up.dot(f)
        if u.length < 1e-8:
            pf = prev_fwd.normalized()
            r  = pf.cross(prev_up)
            if r.length < 1e-8:
                r = Vector((1, 0, 0))
            u = r.cross(f)
        return u.normalized()

    def _bake(self, context, cam_obj, trajectory, props):
        scene = context.scene
        fps   = scene.render.fps if scene.render.fps > 0 else 24

        n_seg           = len(trajectory) - 1
        travel_frames   = max(1, int(round(props.travel_seconds * fps)))
        pause_frames    = int(round(props.pause_seconds * fps))

        wp_positions = [_blender_pos_for_view(v, props.camera_distance) for v in trajectory]
        wp_dirs      = [p.normalized() for p in wp_positions]

        angles      = [math.acos(self._clamp(wp_dirs[i].dot(wp_dirs[i+1]), -1, 1)) for i in range(n_seg)]
        total_angle = sum(angles) or 1.0

        seg_frames, remaining = [], travel_frames
        for i, ang in enumerate(angles):
            n = remaining if i == len(angles) - 1 else max(1, int(round(travel_frames * ang / total_angle)))
            seg_frames.append(n)
            remaining -= n

        cam_obj.animation_data_clear()
        cam_obj.rotation_mode = "QUATERNION"

        def key_pose(f, pos, q):
            cam_obj.location            = pos
            cam_obj.rotation_quaternion = q
            cam_obj.keyframe_insert(data_path="location",            frame=f)
            cam_obj.keyframe_insert(data_path="rotation_quaternion", frame=f)

        frame   = 1
        pos     = wp_dirs[0] * props.camera_distance
        forward = (-pos).normalized()
        wz, wy  = Vector((0, 0, 1)), Vector((0, 1, 0))
        init_up = wz if abs(forward.dot(wz)) <= 0.95 else wy
        up      = (init_up - forward * init_up.dot(forward)).normalized()
        q       = self._rotation_from_forward_up(forward, up)
        key_pose(frame, pos, q)
        prev_fwd, prev_up = forward.copy(), up.copy()

        for _ in range(pause_frames):
            frame += 1
            key_pose(frame, pos, q)

        for i in range(n_seg):
            u, v   = wp_dirs[i], wp_dirs[i + 1]
            nframes = seg_frames[i]
            for step in range(1, nframes + 1):
                t       = step / nframes
                d       = self._slerp(u, v, t)
                pos     = d * props.camera_distance
                forward = (-pos).normalized()
                up      = self._parallel_transport_up(prev_fwd, forward, prev_up)
                q       = self._rotation_from_forward_up(forward, up)
                frame  += 1
                key_pose(frame, pos, q)
                prev_fwd, prev_up = forward, up

            for _ in range(pause_frames):
                frame += 1
                key_pose(frame, pos, q)

        scene.frame_start = 1
        scene.frame_end   = frame
        scene.render.film_transparent = True

        if cam_obj.animation_data and cam_obj.animation_data.action:
            for fcu in cam_obj.animation_data.action.fcurves:
                for kp in fcu.keyframe_points:
                    kp.interpolation = "LINEAR"


# ---------------------------------------------------------------------------
# Operator: Normalize Mesh
# ---------------------------------------------------------------------------

class NOVELVIEWS_OT_normalize_mesh(Operator):
    bl_idname  = "novelviews.normalize_mesh"
    bl_label   = "Normalize Mesh"
    bl_description = (
        "Center the active mesh at the origin and scale it so its bounding sphere "
        "matches Hunyuan3D's preprocessing (diameter = Bounding Sphere Diameter)"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.novelviews_props
        obj   = context.active_object

        if obj is None:
            self.report({"ERROR"}, "No object selected — please select a mesh first.")
            return {"CANCELLED"}
        if obj.type != "MESH":
            self.report({"ERROR"}, f"'{obj.name}' is not a mesh (type: {obj.type}).")
            return {"CANCELLED"}

        wm       = obj.matrix_world
        verts    = [wm @ v.co for v in obj.data.vertices]
        if not verts:
            self.report({"ERROR"}, "Mesh has no vertices.")
            return {"CANCELLED"}

        min_co = Vector((min(v.x for v in verts), min(v.y for v in verts), min(v.z for v in verts)))
        max_co = Vector((max(v.x for v in verts), max(v.y for v in verts), max(v.z for v in verts)))
        center  = (min_co + max_co) / 2

        max_dist = max((v - center).length for v in verts)
        diameter = max_dist * 2.0
        if diameter == 0:
            self.report({"ERROR"}, "Mesh has zero size.")
            return {"CANCELLED"}

        scale = props.mesh_scale_factor / diameter
        obj.location = obj.location - center
        obj.scale    = obj.scale * scale

        context.view_layer.objects.active = obj
        bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)

        self.report({"INFO"}, (
            f"Normalized '{obj.name}': "
            f"original diameter={diameter:.4f}, scale applied={scale:.4f}, "
            f"target diameter={props.mesh_scale_factor}"
        ))
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class NOVELVIEWS_PT_main_panel(Panel):
    bl_label      = "NovelViews Assets"
    bl_idname     = "NOVELVIEWS_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category   = "NovelViews"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.novelviews_props

        # ---- Camera Setup ----
        box = layout.box()
        box.label(text="Camera Setup", icon="CAMERA_DATA")
        col = box.column(align=True)
        col.prop(props, "camera_distance")
        col.prop(props, "ortho_scale")
        col.prop(props, "render_size")
        col.prop(props, "use_constraints")
        box.operator("novelviews.setup_cameras", icon="SCENE")

        layout.separator()

        # ---- Camera Tour ----
        box = layout.box()
        box.label(text="Camera Tour", icon="ANIM")
        col = box.column(align=True)
        col.prop(props, "travel_seconds")
        col.prop(props, "pause_seconds")
        box.operator("novelviews.camera_tour", icon="PLAY")

        layout.separator()

        # ---- Normalize Mesh ----
        box = layout.box()
        box.label(text="Normalize Mesh", icon="MESH_DATA")
        col = box.column(align=True)
        col.prop(props, "mesh_scale_factor")
        box.operator("novelviews.normalize_mesh", icon="MODIFIER")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_classes = [
    NovelViewsProperties,
    NOVELVIEWS_OT_setup_cameras,
    NOVELVIEWS_OT_camera_tour,
    NOVELVIEWS_OT_normalize_mesh,
    NOVELVIEWS_PT_main_panel,
]


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.novelviews_props = PointerProperty(type=NovelViewsProperties)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.novelviews_props


if __name__ == "__main__":
    register()
